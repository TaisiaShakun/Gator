﻿using Gator.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Gator.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult<string> Send([FromBody] Points model)
        {
            var (type, text) = CatchErrors(model);
            if (type == "Error")
                return StatusCode(500, text);
            else return Ok(text);


        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private static Tuple<string, string> CatchErrors(Points model)
        {
           if (model.EndPoint.Lat > 90 || model.EndPoint.Lat < -90)
            return new Tuple<string, string>("Error", "Wrong End point Lat");
           else if (model.StartPoint.Lat > 90 || model.StartPoint.Lat < -90)
                return new Tuple<string, string>("Error", "Wrong Start point Lat");
            else if (model.StartPoint.Lng > 180 || model.StartPoint.Lng < -180)
                return new Tuple<string, string>("Error", "Wrong Start point Lng");
            else if (model.EndPoint.Lng > 180 || model.EndPoint.Lng < -180)
                return new Tuple<string, string>("Error", "Wrong End point Lng");
            else return new Tuple<string, string>("Ok", "Success");

        }
    }
}
