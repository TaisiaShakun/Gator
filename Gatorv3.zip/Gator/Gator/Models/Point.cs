﻿namespace Gator.Models
{
    public class Point
    {
        public decimal Lat { get; set; }
        public decimal Lng { get; set; }
    }
}
