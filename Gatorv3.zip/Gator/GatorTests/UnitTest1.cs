using Gator.Controllers;
using Gator.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using Xunit;

namespace GatorTests
{
    public class UnitTest1
    {
        [Fact]
        public void HomeController_Send_CorrectPoints_Success()
        {
            var controller = new HomeController();
            var points = new Points
            {
                StartPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                },
                EndPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                }
            };

            var result = controller.Send(points);

            Assert.Equal("Success", ((ObjectResult)result.Result).Value);
        }
        [Fact]
        public void HomeController_Send_IncorrectPoint_Lat_SP_Success()
        {
            var controller = new HomeController();
            var points = new Points
            {
                StartPoint = new Point
                {
                    Lat = -190,
                    Lng = 45
                },
                EndPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                }
            };

            var result = controller.Send(points);

            Assert.Equal("Wrong Start point Lat", ((ObjectResult)result.Result).Value);
        }
        [Fact]
        public void HomeController_Send_IncorrectPoint_Lng_SP_Success()
        {
            var controller = new HomeController();
            var points = new Points
            {
                StartPoint = new Point
                {
                    Lat = 45,
                    Lng = -190
                },
                EndPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                }
            };

            var result = controller.Send(points);

            Assert.Equal("Wrong Start point Lng", ((ObjectResult)result.Result).Value);
        }
        [Fact]
        public void HomeController_Send_IncorrectPoint_Lng_EP_Success()
        {
            var controller = new HomeController();
            var points = new Points
            {
                StartPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                },
                EndPoint = new Point
                {
                    Lat = -190,
                    Lng = 45
                }
            };

            var result = controller.Send(points);

            Assert.Equal("Wrong End point Lat", ((ObjectResult)result.Result).Value);
        }
        [Fact]
        public void HomeController_Send_IncorrectPoint_Lat_EP_Success()
        {
            var controller = new HomeController();
            var points = new Points
            {
                StartPoint = new Point
                {
                    Lat = 45,
                    Lng = 45
                },
                EndPoint = new Point
                {
                    Lat = 45,
                    Lng = -190
                }
            };

            var result = controller.Send(points);

            Assert.Equal("Wrong End point Lng", ((ObjectResult)result.Result).Value);
        }
    }
}
