﻿namespace Gator.Models
{
    public class Points
    {
        public Point StartPoint { get; set; }
        public Point EndPoint { get; set; }
    }

}
